plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.ridefast.autoaccept"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.ridefast.autoaccept"
        minSdk = 26
        targetSdk = 36
        versionCode = 2
        versionName = "1.1"
    }

    kotlin {
        jvmToolchain(17)
    }
}
