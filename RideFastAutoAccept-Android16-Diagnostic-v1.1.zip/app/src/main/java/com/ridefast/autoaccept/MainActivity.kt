package com.ridefast.autoaccept

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.DateFormat
import java.util.Date

class MainActivity : Activity() {

    private lateinit var statusText: TextView
    private lateinit var eventText: TextView
    private val handler = Handler(Looper.getMainLooper())

    private val refreshRunnable = object : Runnable {
        override fun run() {
            refreshStatus()
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        refreshStatus()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
        handler.removeCallbacks(refreshRunnable)
        handler.post(refreshRunnable)
    }

    override fun onPause() {
        handler.removeCallbacks(refreshRunnable)
        super.onPause()
    }

    private fun buildUi() {
        val padding = (24 * resources.displayMetrics.density).toInt()

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(padding, padding, padding, padding)
            setBackgroundColor(Color.WHITE)
        }

        val title = TextView(this).apply {
            text = "RideFast Auto Accept"
            textSize = 28f
            setTextColor(Color.rgb(20, 20, 20))
            setPadding(0, 0, 0, padding / 2)
        }
        content.addView(title, match())

        val subtitle = TextView(this).apply {
            text = "Android 16 diagnostic build"
            textSize = 16f
            setTextColor(Color.DKGRAY)
            setPadding(0, 0, 0, padding)
        }
        content.addView(subtitle, match())

        statusText = TextView(this).apply {
            textSize = 20f
            setPadding(padding / 2, padding / 2, padding / 2, padding / 2)
        }
        content.addView(statusText, match())

        eventText = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.DKGRAY)
            setPadding(0, padding / 2, 0, padding)
        }
        content.addView(eventText, match())

        val settingsButton = Button(this).apply {
            text = "OPEN ACCESSIBILITY SETTINGS"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        content.addView(settingsButton, match())

        val appInfoButton = Button(this).apply {
            text = "APP INFO"
            setOnClickListener {
                startActivity(
                    Intent(
                        Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:$packageName")
                    )
                )
            }
        }
        content.addView(appInfoButton, match())

        val note = TextView(this).apply {
            text = "
Diagnostic mode only.
No automatic ride acceptance is active yet."
            textSize = 14f
            setTextColor(Color.GRAY)
            setPadding(0, padding, 0, 0)
        }
        content.addView(note, match())

        val scroll = ScrollView(this).apply {
            addView(content)
        }

        setContentView(scroll)
    }

    private fun refreshStatus() {
        val connected = ServiceState.isConnected(this)
        val lastEvent = ServiceState.lastEvent(this)
        val time = ServiceState.lastTime(this)

        statusText.text = if (connected) {
            "Service connected"
        } else {
            "Service not connected"
        }

        statusText.setTextColor(
            if (connected) Color.rgb(0, 140, 70) else Color.rgb(190, 40, 40)
        )

        val formatted = if (time == 0L) {
            "No timestamp"
        } else {
            DateFormat.getDateTimeInstance().format(Date(time))
        }

        eventText.text = "Last event:
$lastEvent

Time:
$formatted"
    }

    private fun match(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
}
