package com.ridefast.autoaccept

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.util.Log
import android.view.accessibility.AccessibilityEvent

class RideAutoAcceptService : AccessibilityService() {

    companion object {
        private const val TAG = "RideFastService"
    }

    override fun onServiceConnected() {
        super.onServiceConnected()

        ServiceState.set(this, "SERVICE CONNECTED", true)
        Log.i(TAG, "SERVICE CONNECTED")

        // Diagnostic/stability stage only.
        // No automatic ride detection or clicking is performed here.
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        val packageName = event.packageName?.toString() ?: "unknown"
        val eventName = when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> "WINDOW STATE: $packageName"
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> "WINDOW CONTENT: $packageName"
            AccessibilityEvent.TYPE_VIEW_CLICKED -> "VIEW CLICKED: $packageName"
            AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED -> "VIEW TEXT: $packageName"
            else -> "EVENT ${event.eventType}: $packageName"
        }

        ServiceState.set(this, eventName, true)
        Log.d(TAG, eventName)
    }

    override fun onInterrupt() {
        ServiceState.set(this, "SERVICE INTERRUPTED", false)
        Log.w(TAG, "SERVICE INTERRUPTED")
    }

    override fun onUnbind(intent: Intent?): Boolean {
        ServiceState.set(this, "SERVICE UNBOUND", false)
        Log.w(TAG, "SERVICE UNBOUND")
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        ServiceState.set(this, "SERVICE DESTROYED", false)
        Log.w(TAG, "SERVICE DESTROYED")
        super.onDestroy()
    }
}
