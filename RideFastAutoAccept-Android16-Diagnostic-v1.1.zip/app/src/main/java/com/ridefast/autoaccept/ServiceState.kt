package com.ridefast.autoaccept

import android.content.Context

object ServiceState {
    private const val PREFS = "ridefast_service_state"
    private const val KEY_EVENT = "last_event"
    private const val KEY_TIME = "last_time"
    private const val KEY_CONNECTED = "connected"

    fun set(context: Context, event: String, connected: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_EVENT, event)
            .putLong(KEY_TIME, System.currentTimeMillis())
            .putBoolean(KEY_CONNECTED, connected)
            .apply()
    }

    fun isConnected(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(KEY_CONNECTED, false)

    fun lastEvent(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_EVENT, "No service event recorded yet")
            ?: "No service event recorded yet"

    fun lastTime(context: Context): Long =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getLong(KEY_TIME, 0L)
}
