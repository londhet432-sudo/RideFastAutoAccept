# RideFast Auto Accept

Android 16 diagnostic foundation for a user-authorized AccessibilityService.

Current stage:
- Android 16 / API 36
- Kotlin
- AccessibilityService lifecycle diagnostics
- Real app status screen
- No automatic clicking or ride acceptance yet

The next stage is to diagnose service stability on the target iQOO device before adding ride-offer detection.
