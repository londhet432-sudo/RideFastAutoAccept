# RideFast Auto Accept V2

Android 16 / API 36 diagnostic and ride-offer detection foundation.

## Current V2 behavior

- AccessibilityService registration
- Target package detection for common Uber/Ola/Rapido package names
- Active-window accessibility-tree retrieval
- Visible text/content-description collection
- Local diagnostic state shown in the app
- GitHub Actions debug APK build

## Important

V2 deliberately does not auto-click a ride yet. The first real-device test must establish exactly what the selected ride application exposes through AccessibilityService. Android documents that an accessibility service with window-content retrieval can inspect the active window through `getRootInActiveWindow()`.

After the real UI is observed, fare parsing, filtering, and any permitted acceptance action can be implemented against verified nodes rather than guessed IDs/text.

This project does not bypass anti-automation controls or guarantee compatibility with third-party ride platforms.
