package com.ridefast.autoaccept

import android.content.Context

object ServiceState {
    private const val PREFS = "ridefast_state"
    private const val EVENT = "event"
    private const val TIME = "time"
    private const val PACKAGE = "package"
    private const val TEXT = "text"

    fun save(context: Context, event: String, packageName: String = "", text: String = "") {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(EVENT, event)
            .putLong(TIME, System.currentTimeMillis())
            .putString(PACKAGE, packageName)
            .putString(TEXT, text.take(4000))
            .apply()
    }

    fun event(context: Context) = prefs(context).getString(EVENT, "No event yet") ?: "No event yet"
    fun time(context: Context) = prefs(context).getLong(TIME, 0L)
    fun packageName(context: Context) = prefs(context).getString(PACKAGE, "") ?: ""
    fun text(context: Context) = prefs(context).getString(TEXT, "") ?: ""

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
