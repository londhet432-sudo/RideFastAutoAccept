package com.ridefast.autoaccept

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var details: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
        }

        val title = TextView(this).apply {
            text = "RideFast Auto Accept V2"
            textSize = 28f
            gravity = Gravity.CENTER
        }

        val subtitle = TextView(this).apply {
            text = "Detection & accessibility diagnostic"
            textSize = 17f
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 24)
        }

        status = TextView(this).apply {
            textSize = 18f
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 18)
        }

        val settings = Button(this).apply {
            text = "OPEN ACCESSIBILITY SETTINGS"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        val refresh = Button(this).apply {
            text = "REFRESH DETECTION STATUS"
            setOnClickListener { refreshStatus() }
        }

        details = TextView(this).apply {
            textSize = 15f
            setPadding(0, 20, 0, 20)
        }

        val note = TextView(this).apply {
            text = "V2 currently scans supported app accessibility text only. " +
                "It does NOT automatically accept rides yet. " +
                "This lets us verify the real UI exposed by the ride app before enabling any action."
            textSize = 15f
            setPadding(0, 20, 0, 20)
        }

        content.addView(title)
        content.addView(subtitle)
        content.addView(status)
        content.addView(settings)
        content.addView(refresh)
        content.addView(details)
        content.addView(note)

        val scroll = ScrollView(this).apply {
            addView(content)
        }

        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun refreshStatus() {
        val event = ServiceState.event(this)
        val pkg = ServiceState.packageName(this)
        val rawText = ServiceState.text(this)
        val time = ServiceState.time(this)

        status.text = if (event.contains("SERVICE CONNECTED")) {
            "Accessibility service: CONNECTED"
        } else {
            "Accessibility service: CHECK SETTINGS"
        }

        val formatted = if (time > 0L) {
            SimpleDateFormat("dd MMM yyyy, HH:mm:ss", Locale.getDefault())
                .format(Date(time))
        } else {
            "No timestamp"
        }

        details.text = buildString {
            append("Last event: $event\n")
            append("Time: $formatted\n")
            append("Package: ${if (pkg.isBlank()) "—" else pkg}\n\n")
            append("Detected text:\n")
            append(if (rawText.isBlank()) "No target-app text captured yet." else rawText)
        }
    }
}
