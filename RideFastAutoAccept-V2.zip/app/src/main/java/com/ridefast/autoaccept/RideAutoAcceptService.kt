package com.ridefast.autoaccept

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.SystemClock
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class RideAutoAcceptService : AccessibilityService() {

    companion object {
        private const val TAG = "RideFastV2"
        private const val SCAN_INTERVAL_MS = 250L

        private val TARGET_PACKAGES = setOf(
            "com.ubercab.driver",
            "com.olacabs.customer",
            "com.olacabs.driver",
            "com.rapido.passenger",
            "com.rapido.rider"
        )
    }

    private var lastScan = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        ServiceState.save(this, "SERVICE CONNECTED")
        Log.i(TAG, "SERVICE CONNECTED")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        val pkg = event.packageName?.toString() ?: return
        val now = SystemClock.uptimeMillis()

        if (now - lastScan < SCAN_INTERVAL_MS) return
        lastScan = now

        if (!isTargetPackage(pkg)) {
            ServiceState.save(this, "OTHER APP", pkg)
            return
        }

        val root = rootInActiveWindow
        if (root == null) {
            ServiceState.save(this, "TARGET WINDOW WITHOUT ROOT", pkg)
            return
        }

        val texts = ArrayList<String>()
        collectText(root, texts)

        val uniqueText = texts
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .distinct()
            .take(250)

        val combined = uniqueText.joinToString(" | ")

        ServiceState.save(
            this,
            "TARGET APP SCANNED",
            pkg,
            combined
        )

        Log.d(TAG, "TARGET=$pkg TEXT=$combined")

        // V2 intentionally performs detection/inspection only.
        // No automatic click is executed until the real target UI
        // has been observed and verified on the user's device.
    }

    private fun isTargetPackage(pkg: String): Boolean {
        return TARGET_PACKAGES.contains(pkg) ||
            pkg.contains("uber", ignoreCase = true) ||
            pkg.contains("ola", ignoreCase = true) ||
            pkg.contains("rapido", ignoreCase = true)
    }

    private fun collectText(node: AccessibilityNodeInfo, output: MutableList<String>) {
        node.text?.toString()?.let { if (it.isNotBlank()) output.add(it) }
        node.contentDescription?.toString()?.let { if (it.isNotBlank()) output.add(it) }

        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { child ->
                collectText(child, output)
                child.recycle()
            }
        }
    }

    override fun onInterrupt() {
        ServiceState.save(this, "SERVICE INTERRUPTED")
        Log.w(TAG, "SERVICE INTERRUPTED")
    }

    override fun onUnbind(intent: Intent?): Boolean {
        ServiceState.save(this, "SERVICE UNBOUND")
        Log.w(TAG, "SERVICE UNBOUND")
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        ServiceState.save(this, "SERVICE DESTROYED")
        Log.w(TAG, "SERVICE DESTROYED")
        super.onDestroy()
    }
}
